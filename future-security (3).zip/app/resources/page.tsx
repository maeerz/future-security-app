import Link from "next/link"
import { Shield, Search, Download, ExternalLink, BookOpen, FileText, Video, Code } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function ResourcesPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <div className="flex items-center gap-2 font-bold">
            <Shield className="h-6 w-6 text-emerald-500" />
            <Link href="/">Future Security 1.0</Link>
          </div>
          <nav className="ml-auto flex gap-4 sm:gap-6">
            <Link href="/" className="text-sm font-medium">
              Dashboard
            </Link>
            <Link href="/lessons" className="text-sm font-medium">
              Lessons
            </Link>
            <Link href="/resources" className="text-sm font-medium text-emerald-500 underline underline-offset-4">
              Resources
            </Link>
            <Link href="/certificates" className="text-sm font-medium">
              Certificates
            </Link>
            <Link href="/admin" className="text-sm font-medium">
              Admin
            </Link>
          </nav>
        </div>
      </header>
      <main className="flex-1">
        <div className="container py-8">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
              <h1 className="text-3xl font-bold">Cybersecurity Resources</h1>
              <p className="text-muted-foreground">Additional materials to enhance your cybersecurity knowledge</p>
            </div>
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search resources..."
                className="w-full rounded-md pl-8 md:w-[200px] lg:w-[300px]"
              />
            </div>
          </div>

          <Tabs defaultValue="all" className="mt-6">
            <TabsList>
              <TabsTrigger value="all">All Resources</TabsTrigger>
              <TabsTrigger value="guides">Guides</TabsTrigger>
              <TabsTrigger value="tools">Tools</TabsTrigger>
              <TabsTrigger value="videos">Videos</TabsTrigger>
              <TabsTrigger value="code">Code Samples</TabsTrigger>
            </TabsList>
            <TabsContent value="all" className="mt-6">
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {resources.map((resource) => (
                  <ResourceCard key={resource.id} resource={resource} />
                ))}
              </div>
            </TabsContent>
            <TabsContent value="guides" className="mt-6">
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {resources
                  .filter((resource) => resource.type === "Guide")
                  .map((resource) => (
                    <ResourceCard key={resource.id} resource={resource} />
                  ))}
              </div>
            </TabsContent>
            <TabsContent value="tools" className="mt-6">
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {resources
                  .filter((resource) => resource.type === "Tool")
                  .map((resource) => (
                    <ResourceCard key={resource.id} resource={resource} />
                  ))}
              </div>
            </TabsContent>
            <TabsContent value="videos" className="mt-6">
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {resources
                  .filter((resource) => resource.type === "Video")
                  .map((resource) => (
                    <ResourceCard key={resource.id} resource={resource} />
                  ))}
              </div>
            </TabsContent>
            <TabsContent value="code" className="mt-6">
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {resources
                  .filter((resource) => resource.type === "Code")
                  .map((resource) => (
                    <ResourceCard key={resource.id} resource={resource} />
                  ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <footer className="border-t py-6 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-24 md:flex-row">
          <div className="flex items-center gap-2 font-bold">
            <Shield className="h-5 w-5 text-emerald-500" />
            <span>Future Security 1.0</span>
          </div>
          <p className="text-center text-sm leading-loose text-muted-foreground md:text-left">
            © 2025 Future Security. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  )
}

function ResourceCard({ resource }) {
  const getIcon = (type) => {
    switch (type) {
      case "Guide":
        return <BookOpen className="h-5 w-5" />
      case "Tool":
        return <FileText className="h-5 w-5" />
      case "Video":
        return <Video className="h-5 w-5" />
      case "Code":
        return <Code className="h-5 w-5" />
      default:
        return <FileText className="h-5 w-5" />
    }
  }

  return (
    <Card className="flex flex-col">
      <CardHeader>
        <div className="flex items-center justify-between">
          <Badge variant="outline" className="flex items-center gap-1">
            {getIcon(resource.type)}
            {resource.type}
          </Badge>
          <Badge variant="secondary">{resource.category}</Badge>
        </div>
        <CardTitle className="mt-2">{resource.title}</CardTitle>
        <CardDescription>{resource.description}</CardDescription>
      </CardHeader>
      <CardContent className="flex-1">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <span>Added: {resource.dateAdded}</span>
        </div>
      </CardContent>
      <CardFooter className="flex gap-2">
        {resource.downloadUrl && (
          <Button variant="outline" className="flex-1">
            <Download className="mr-2 h-4 w-4" />
            Download
          </Button>
        )}
        {resource.externalUrl && (
          <Button className="flex-1">
            <ExternalLink className="mr-2 h-4 w-4" />
            View Resource
          </Button>
        )}
      </CardFooter>
    </Card>
  )
}

const resources = [
  {
    id: "1",
    title: "OWASP Top 10 Security Risks",
    description: "A comprehensive guide to the most critical web application security risks",
    type: "Guide",
    category: "Web Security",
    dateAdded: "June 1, 2025",
    externalUrl: "https://example.com/owasp-top-10",
  },
  {
    id: "2",
    title: "Network Security Checklist",
    description: "A checklist for securing your organization's network infrastructure",
    type: "Guide",
    category: "Network Security",
    dateAdded: "May 15, 2025",
    downloadUrl: "/resources/network-security-checklist.pdf",
  },
  {
    id: "3",
    title: "Wireshark Tutorial",
    description: "Learn how to use Wireshark for network traffic analysis",
    type: "Video",
    category: "Network Security",
    dateAdded: "May 10, 2025",
    externalUrl: "https://example.com/wireshark-tutorial",
  },
  {
    id: "4",
    title: "Password Policy Generator",
    description: "Tool to generate secure password policies for your organization",
    type: "Tool",
    category: "Access Control",
    dateAdded: "June 5, 2025",
    externalUrl: "https://example.com/password-policy-generator",
  },
  {
    id: "5",
    title: "Secure API Implementation",
    description: "Code samples for implementing secure APIs with authentication and authorization",
    type: "Code",
    category: "Application Security",
    dateAdded: "May 28, 2025",
    downloadUrl: "/resources/secure-api-samples.zip",
  },
  {
    id: "6",
    title: "Incident Response Plan Template",
    description: "Template for creating an effective cybersecurity incident response plan",
    type: "Guide",
    category: "Incident Response",
    dateAdded: "June 3, 2025",
    downloadUrl: "/resources/incident-response-template.docx",
  },
  {
    id: "7",
    title: "Social Engineering Defense Strategies",
    description: "Learn how to protect your organization from social engineering attacks",
    type: "Video",
    category: "Social Engineering",
    dateAdded: "May 20, 2025",
    externalUrl: "https://example.com/social-engineering-defense",
  },
  {
    id: "8",
    title: "Secure Coding Guidelines",
    description: "Best practices for writing secure code across different programming languages",
    type: "Guide",
    category: "Application Security",
    dateAdded: "June 7, 2025",
    downloadUrl: "/resources/secure-coding-guidelines.pdf",
  },
  {
    id: "9",
    title: "Vulnerability Scanner Configuration",
    description: "Configuration files and scripts for popular vulnerability scanners",
    type: "Code",
    category: "Vulnerability Management",
    dateAdded: "May 25, 2025",
    downloadUrl: "/resources/vulnerability-scanner-configs.zip",
  },
]
