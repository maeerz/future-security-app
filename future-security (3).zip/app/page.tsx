import Link from "next/link"
import { Shield, BookOpen, BarChart, Users, Settings } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { ProgressDashboard } from "@/components/progress-dashboard"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <div className="flex items-center gap-2 font-bold">
            <Shield className="h-6 w-6 text-emerald-500" />
            <span>Future Security 1.0</span>
          </div>
          <nav className="ml-auto flex gap-4 sm:gap-6">
            <Link href="/" className="text-sm font-medium">
              Dashboard
            </Link>
            <Link href="/lessons" className="text-sm font-medium">
              Lessons
            </Link>
            <Link href="/resources" className="text-sm font-medium">
              Resources
            </Link>
            <Link href="/certificates" className="text-sm font-medium">
              Certificates
            </Link>
            <Link href="/admin" className="text-sm font-medium">
              Admin
            </Link>
          </nav>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-emerald-50 to-white dark:from-emerald-950/20 dark:to-background">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                    Learn Cybersecurity Skills for the Future
                  </h1>
                  <p className="max-w-[600px] text-muted-foreground md:text-xl">
                    Comprehensive cybersecurity education platform designed to keep your skills sharp and your systems
                    secure.
                  </p>
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Link href="/lessons">
                    <Button size="lg">Start Learning</Button>
                  </Link>
                  <Link href="/resources">
                    <Button size="lg" variant="outline">
                      Browse Resources
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <div className="relative h-[350px] w-full overflow-hidden rounded-xl border bg-background p-2">
                  <div className="absolute inset-0 bg-gradient-to-r from-emerald-500/20 via-cyan-500/20 to-blue-500/20 opacity-50"></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Shield className="h-24 w-24 text-emerald-500" />
                  </div>
                  <div className="absolute bottom-4 left-4 right-4 rounded-lg bg-background/90 p-4 backdrop-blur">
                    <div className="text-sm font-medium">Featured Course</div>
                    <div className="text-xl font-bold">Network Security Fundamentals</div>
                    <div className="mt-1 text-xs text-muted-foreground">
                      Learn how to secure your networks against common threats
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="mx-auto flex max-w-[58rem] flex-col items-center justify-center gap-4 text-center mb-8">
              <h2 className="font-heading text-3xl leading-[1.1] sm:text-3xl md:text-6xl">Your Learning Progress</h2>
              <p className="max-w-[85%] leading-normal text-muted-foreground sm:text-lg sm:leading-7">
                Track your cybersecurity learning journey and achievements
              </p>
            </div>
            <ProgressDashboard />
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="mx-auto flex max-w-[58rem] flex-col items-center justify-center gap-4 text-center">
              <h2 className="font-heading text-3xl leading-[1.1] sm:text-3xl md:text-6xl">
                Featured Cybersecurity Topics
              </h2>
              <p className="max-w-[85%] leading-normal text-muted-foreground sm:text-lg sm:leading-7">
                Explore our most popular cybersecurity lessons and stay ahead of emerging threats
              </p>
            </div>
            <div className="mx-auto grid justify-center gap-4 sm:grid-cols-2 md:max-w-[64rem] md:grid-cols-3 lg:gap-8 mt-8">
              {featuredTopics.map((topic) => (
                <Card key={topic.title} className="flex flex-col">
                  <CardHeader>
                    <CardTitle>{topic.title}</CardTitle>
                    <CardDescription>{topic.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="flex-1">{topic.content}</CardContent>
                  <CardFooter>
                    <Link href={`/lessons/${topic.slug}`} className="w-full">
                      <Button className="w-full">Start Learning</Button>
                    </Link>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </div>
        </section>
        <section className="w-full py-12 md:py-24 lg:py-32 bg-muted/50">
          <div className="container px-4 md:px-6">
            <div className="mx-auto flex max-w-[58rem] flex-col items-center justify-center gap-4 text-center">
              <h2 className="font-heading text-3xl leading-[1.1] sm:text-3xl md:text-6xl">
                Why Choose Future Security
              </h2>
              <p className="max-w-[85%] leading-normal text-muted-foreground sm:text-lg sm:leading-7">
                Our platform offers comprehensive cybersecurity education with regular updates from industry experts
              </p>
            </div>
            <div className="mx-auto grid justify-center gap-4 sm:grid-cols-2 md:max-w-[64rem] md:grid-cols-3 lg:gap-8 mt-8">
              {features.map((feature) => (
                <Card key={feature.title} className="flex flex-col items-center text-center p-6">
                  <feature.icon className="h-12 w-12 text-emerald-500 mb-4" />
                  <CardTitle>{feature.title}</CardTitle>
                  <CardContent className="flex-1 pt-4">
                    <p>{feature.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>
      </main>
      <footer className="border-t py-6 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-24 md:flex-row">
          <div className="flex items-center gap-2 font-bold">
            <Shield className="h-5 w-5 text-emerald-500" />
            <span>Future Security 1.0</span>
          </div>
          <p className="text-center text-sm leading-loose text-muted-foreground md:text-left">
            © 2025 Future Security. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  )
}

const featuredTopics = [
  {
    title: "Network Security",
    description: "Protect your organization's network infrastructure",
    content:
      "Learn about firewalls, intrusion detection systems, VPNs, and network segmentation to secure your organization's critical infrastructure.",
    slug: "network-security",
  },
  {
    title: "Social Engineering",
    description: "Defend against human-targeted attacks",
    content:
      "Understand the psychological tactics used by attackers and develop strategies to recognize and prevent social engineering attacks.",
    slug: "social-engineering",
  },
  {
    title: "Secure Coding Practices",
    description: "Build security into your applications",
    content:
      "Learn how to write secure code, identify common vulnerabilities, and implement security best practices in your development workflow.",
    slug: "secure-coding",
  },
]

const features = [
  {
    title: "Up-to-date Content",
    description:
      "Our team regularly updates the platform with the latest cybersecurity trends, threats, and defense strategies.",
    icon: BookOpen,
  },
  {
    title: "Progress Tracking",
    description: "Track your team's learning progress with detailed analytics and completion certificates.",
    icon: BarChart,
  },
  {
    title: "Team Collaboration",
    description: "Collaborate with your team members, share insights, and learn together in a secure environment.",
    icon: Users,
  },
  {
    title: "Customizable Platform",
    description:
      "Easily update and customize content to match your organization's specific security needs and policies.",
    icon: Settings,
  },
]
