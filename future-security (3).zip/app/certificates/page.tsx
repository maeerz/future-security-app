"use client"

import Link from "next/link"
import { Shield, Download, Calendar, Trophy, Award } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useProgress } from "@/contexts/progress-context"
import { downloadCertificate, type CertificateData } from "@/lib/certificate-generator"

export default function CertificatesPage() {
  const { certificates, getOverallProgress } = useProgress()
  const overallProgress = getOverallProgress()

  const handleDownloadCertificate = (certificate: any) => {
    const certificateData: CertificateData = {
      studentName: "Cybersecurity Student", // In a real app, this would come from user data
      lessonTitle: certificate.lessonTitle,
      completionDate: new Date(certificate.earnedDate).toLocaleDateString("en-US", {
        year: "numeric",
        month: "long",
        day: "numeric",
      }),
      score: certificate.score,
      duration: certificate.duration,
      certificateId: certificate.id,
    }

    downloadCertificate(certificateData)
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <div className="flex items-center gap-2 font-bold">
            <Shield className="h-6 w-6 text-emerald-500" />
            <Link href="/">Future Security 1.0</Link>
          </div>
          <nav className="ml-auto flex gap-4 sm:gap-6">
            <Link href="/" className="text-sm font-medium">
              Dashboard
            </Link>
            <Link href="/lessons" className="text-sm font-medium">
              Lessons
            </Link>
            <Link href="/resources" className="text-sm font-medium">
              Resources
            </Link>
            <Link href="/certificates" className="text-sm font-medium text-emerald-500 underline underline-offset-4">
              Certificates
            </Link>
            <Link href="/admin" className="text-sm font-medium">
              Admin
            </Link>
          </nav>
        </div>
      </header>
      <main className="flex-1">
        <div className="container py-8">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
              <h1 className="text-3xl font-bold">Your Certificates</h1>
              <p className="text-muted-foreground">Download and manage your cybersecurity course certificates</p>
            </div>
          </div>

          {/* Statistics Cards */}
          <div className="grid gap-4 md:grid-cols-3 mt-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Certificates Earned</CardTitle>
                <Award className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{certificates.length}</div>
                <p className="text-xs text-muted-foreground">of {overallProgress.completedLessons} completed lessons</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Average Score</CardTitle>
                <Trophy className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {certificates.length > 0
                    ? Math.round(
                        certificates.filter((cert) => cert.score).reduce((sum, cert) => sum + (cert.score || 0), 0) /
                          certificates.filter((cert) => cert.score).length,
                      )
                    : 0}
                  %
                </div>
                <p className="text-xs text-muted-foreground">across all completed courses</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Latest Certificate</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {certificates.length > 0
                    ? new Date(
                        Math.max(...certificates.map((cert) => new Date(cert.earnedDate).getTime())),
                      ).toLocaleDateString("en-US", { month: "short", day: "numeric" })
                    : "None"}
                </div>
                <p className="text-xs text-muted-foreground">most recent completion</p>
              </CardContent>
            </Card>
          </div>

          {/* Certificates List */}
          <div className="mt-8">
            {certificates.length === 0 ? (
              <Card className="text-center py-12">
                <CardContent>
                  <Award className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No Certificates Yet</h3>
                  <p className="text-muted-foreground mb-4">Complete lessons and pass quizzes to earn certificates</p>
                  <Link href="/lessons">
                    <Button>Browse Lessons</Button>
                  </Link>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {certificates
                  .sort((a, b) => new Date(b.earnedDate).getTime() - new Date(a.earnedDate).getTime())
                  .map((certificate) => (
                    <Card key={certificate.id} className="border-emerald-200">
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <Badge variant="default" className="bg-emerald-500">
                            <Award className="h-3 w-3 mr-1" />
                            Certified
                          </Badge>
                          <Badge variant="outline">{certificate.score ? `${certificate.score}%` : "Completed"}</Badge>
                        </div>
                        <CardTitle className="mt-2">{certificate.lessonTitle}</CardTitle>
                        <CardDescription>
                          Earned on{" "}
                          {new Date(certificate.earnedDate).toLocaleDateString("en-US", {
                            year: "numeric",
                            month: "long",
                            day: "numeric",
                          })}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2 text-sm text-muted-foreground mb-4">
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4" />
                            <span>Duration: {certificate.duration}</span>
                          </div>
                          {certificate.score && (
                            <div className="flex items-center gap-2">
                              <Trophy className="h-4 w-4" />
                              <span>Final Score: {certificate.score}%</span>
                            </div>
                          )}
                          <div className="flex items-center gap-2">
                            <Shield className="h-4 w-4" />
                            <span className="text-xs">ID: {certificate.id.slice(-8)}</span>
                          </div>
                        </div>
                        <Button
                          onClick={() => handleDownloadCertificate(certificate)}
                          className="w-full"
                          variant="outline"
                        >
                          <Download className="mr-2 h-4 w-4" />
                          Download PDF
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            )}
          </div>
        </div>
      </main>
      <footer className="border-t py-6 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-24 md:flex-row">
          <div className="flex items-center gap-2 font-bold">
            <Shield className="h-5 w-5 text-emerald-500" />
            <span>Future Security 1.0</span>
          </div>
          <p className="text-center text-sm leading-loose text-muted-foreground md:text-left">
            © 2025 Future Security. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  )
}
