"use client"

import { useState } from "react"
import Link from "next/link"
import { Shield, Plus, Pencil, Trash2, Save, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"

export default function AdminPage() {
  const [lessons, setLessons] = useState(initialLessons)
  const [editingLesson, setEditingLesson] = useState(null)
  const [newLesson, setNewLesson] = useState({
    id: "",
    title: "",
    description: "",
    category: "",
    difficulty: "",
    duration: "",
    content: [],
  })

  const handleEditLesson = (lesson) => {
    setEditingLesson({ ...lesson })
  }

  const handleSaveLesson = () => {
    setLessons(lessons.map((lesson) => (lesson.id === editingLesson.id ? editingLesson : lesson)))
    setEditingLesson(null)
  }

  const handleDeleteLesson = (id) => {
    setLessons(lessons.filter((lesson) => lesson.id !== id))
  }

  const handleAddLesson = () => {
    if (newLesson.id && newLesson.title) {
      setLessons([...lessons, { ...newLesson, content: [], resources: [], quiz: [], relatedLessons: [] }])
      setNewLesson({
        id: "",
        title: "",
        description: "",
        category: "",
        difficulty: "",
        duration: "",
        content: [],
      })
    }
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <div className="flex items-center gap-2 font-bold">
            <Shield className="h-6 w-6 text-emerald-500" />
            <Link href="/">Future Security 1.0</Link>
          </div>
          <nav className="ml-auto flex gap-4 sm:gap-6">
            <Link href="/" className="text-sm font-medium">
              Dashboard
            </Link>
            <Link href="/lessons" className="text-sm font-medium">
              Lessons
            </Link>
            <Link href="/resources" className="text-sm font-medium">
              Resources
            </Link>
            <Link href="/certificates" className="text-sm font-medium">
              Certificates
            </Link>
            <Link href="/admin" className="text-sm font-medium text-emerald-500 underline underline-offset-4">
              Admin
            </Link>
          </nav>
        </div>
      </header>
      <main className="flex-1">
        <div className="container py-8">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
              <h1 className="text-3xl font-bold">Admin Dashboard</h1>
              <p className="text-muted-foreground">Manage your cybersecurity education content</p>
            </div>
          </div>

          <Tabs defaultValue="lessons" className="mt-6">
            <TabsList>
              <TabsTrigger value="lessons">Lessons</TabsTrigger>
              <TabsTrigger value="users">Users</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>
            <TabsContent value="lessons" className="mt-6 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Add New Lesson</CardTitle>
                  <CardDescription>Create a new cybersecurity lesson for your platform</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="grid gap-2">
                      <Label htmlFor="lesson-id">Lesson ID</Label>
                      <Input
                        id="lesson-id"
                        placeholder="e.g., network-security-101"
                        value={newLesson.id}
                        onChange={(e) => setNewLesson({ ...newLesson, id: e.target.value })}
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="lesson-title">Title</Label>
                      <Input
                        id="lesson-title"
                        placeholder="Lesson title"
                        value={newLesson.title}
                        onChange={(e) => setNewLesson({ ...newLesson, title: e.target.value })}
                      />
                    </div>
                    <div className="grid gap-2 sm:col-span-2">
                      <Label htmlFor="lesson-description">Description</Label>
                      <Textarea
                        id="lesson-description"
                        placeholder="Brief description of the lesson"
                        value={newLesson.description}
                        onChange={(e) => setNewLesson({ ...newLesson, description: e.target.value })}
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="lesson-category">Category</Label>
                      <Select
                        value={newLesson.category}
                        onValueChange={(value) => setNewLesson({ ...newLesson, category: value })}
                      >
                        <SelectTrigger id="lesson-category">
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Network Security">Network Security</SelectItem>
                          <SelectItem value="Application Security">Application Security</SelectItem>
                          <SelectItem value="Cloud Security">Cloud Security</SelectItem>
                          <SelectItem value="Compliance">Compliance</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="lesson-difficulty">Difficulty</Label>
                      <Select
                        value={newLesson.difficulty}
                        onValueChange={(value) => setNewLesson({ ...newLesson, difficulty: value })}
                      >
                        <SelectTrigger id="lesson-difficulty">
                          <SelectValue placeholder="Select difficulty" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Beginner">Beginner</SelectItem>
                          <SelectItem value="Intermediate">Intermediate</SelectItem>
                          <SelectItem value="Advanced">Advanced</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="lesson-duration">Duration</Label>
                      <Input
                        id="lesson-duration"
                        placeholder="e.g., 2 hours"
                        value={newLesson.duration}
                        onChange={(e) => setNewLesson({ ...newLesson, duration: e.target.value })}
                      />
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button onClick={handleAddLesson}>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Lesson
                  </Button>
                </CardFooter>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Manage Lessons</CardTitle>
                  <CardDescription>Edit or delete existing lessons</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Title</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Difficulty</TableHead>
                        <TableHead>Duration</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {lessons.map((lesson) => (
                        <TableRow key={lesson.id}>
                          <TableCell className="font-medium">{lesson.title}</TableCell>
                          <TableCell>{lesson.category}</TableCell>
                          <TableCell>
                            <Badge variant={getBadgeVariant(lesson.difficulty)}>{lesson.difficulty}</Badge>
                          </TableCell>
                          <TableCell>{lesson.duration}</TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button variant="outline" size="icon" onClick={() => handleEditLesson(lesson)}>
                                <Pencil className="h-4 w-4" />
                                <span className="sr-only">Edit</span>
                              </Button>
                              <Button variant="outline" size="icon" onClick={() => handleDeleteLesson(lesson.id)}>
                                <Trash2 className="h-4 w-4" />
                                <span className="sr-only">Delete</span>
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>

              {editingLesson && (
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle>Edit Lesson</CardTitle>
                      <CardDescription>Update lesson details</CardDescription>
                    </div>
                    <Button variant="outline" size="icon" onClick={() => setEditingLesson(null)}>
                      <X className="h-4 w-4" />
                      <span className="sr-only">Close</span>
                    </Button>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-4 sm:grid-cols-2">
                      <div className="grid gap-2">
                        <Label htmlFor="edit-lesson-title">Title</Label>
                        <Input
                          id="edit-lesson-title"
                          value={editingLesson.title}
                          onChange={(e) => setEditingLesson({ ...editingLesson, title: e.target.value })}
                        />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="edit-lesson-category">Category</Label>
                        <Select
                          value={editingLesson.category}
                          onValueChange={(value) => setEditingLesson({ ...editingLesson, category: value })}
                        >
                          <SelectTrigger id="edit-lesson-category">
                            <SelectValue placeholder="Select category" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Network Security">Network Security</SelectItem>
                            <SelectItem value="Application Security">Application Security</SelectItem>
                            <SelectItem value="Cloud Security">Cloud Security</SelectItem>
                            <SelectItem value="Compliance">Compliance</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="grid gap-2 sm:col-span-2">
                        <Label htmlFor="edit-lesson-description">Description</Label>
                        <Textarea
                          id="edit-lesson-description"
                          value={editingLesson.description}
                          onChange={(e) => setEditingLesson({ ...editingLesson, description: e.target.value })}
                        />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="edit-lesson-difficulty">Difficulty</Label>
                        <Select
                          value={editingLesson.difficulty}
                          onValueChange={(value) => setEditingLesson({ ...editingLesson, difficulty: value })}
                        >
                          <SelectTrigger id="edit-lesson-difficulty">
                            <SelectValue placeholder="Select difficulty" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Beginner">Beginner</SelectItem>
                            <SelectItem value="Intermediate">Intermediate</SelectItem>
                            <SelectItem value="Advanced">Advanced</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="edit-lesson-duration">Duration</Label>
                        <Input
                          id="edit-lesson-duration"
                          value={editingLesson.duration}
                          onChange={(e) => setEditingLesson({ ...editingLesson, duration: e.target.value })}
                        />
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button onClick={handleSaveLesson}>
                      <Save className="mr-2 h-4 w-4" />
                      Save Changes
                    </Button>
                  </CardFooter>
                </Card>
              )}
            </TabsContent>
            <TabsContent value="users" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>User Management</CardTitle>
                  <CardDescription>Manage user accounts and permissions</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Role</TableHead>
                        <TableHead>Last Active</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {users.map((user) => (
                        <TableRow key={user.id}>
                          <TableCell className="font-medium">{user.name}</TableCell>
                          <TableCell>{user.email}</TableCell>
                          <TableCell>{user.role}</TableCell>
                          <TableCell>{user.lastActive}</TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button variant="outline" size="sm">
                                Edit
                              </Button>
                              <Button variant="outline" size="sm">
                                Suspend
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="settings" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Platform Settings</CardTitle>
                  <CardDescription>Configure your cybersecurity education platform</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="platform-name">Platform Name</Label>
                      <Input id="platform-name" defaultValue="Future Security 1.0" />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="platform-description">Platform Description</Label>
                      <Textarea
                        id="platform-description"
                        defaultValue="A comprehensive cybersecurity education platform"
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="contact-email">Contact Email</Label>
                      <Input id="contact-email" type="email" defaultValue="admin@futuresecurity.com" />
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button>Save Settings</Button>
                </CardFooter>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <footer className="border-t py-6 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-24 md:flex-row">
          <div className="flex items-center gap-2 font-bold">
            <Shield className="h-5 w-5 text-emerald-500" />
            <span>Future Security 1.0</span>
          </div>
          <p className="text-center text-sm leading-loose text-muted-foreground md:text-left">
            © 2025 Future Security. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  )
}

function getBadgeVariant(difficulty) {
  switch (difficulty) {
    case "Beginner":
      return "secondary"
    case "Intermediate":
      return "default"
    case "Advanced":
      return "destructive"
    default:
      return "outline"
  }
}

const initialLessons = [
  {
    id: "network-fundamentals",
    title: "Network Security Fundamentals",
    description: "Learn the basics of securing network infrastructure",
    category: "Network Security",
    difficulty: "Beginner",
    duration: "2 hours",
  },
  {
    id: "firewall-configuration",
    title: "Firewall Configuration Best Practices",
    description: "Configure firewalls to protect your network perimeter",
    category: "Network Security",
    difficulty: "Intermediate",
    duration: "3 hours",
  },
  {
    id: "secure-coding",
    title: "Secure Coding Practices",
    description: "Write code that's resistant to common vulnerabilities",
    category: "Application Security",
    difficulty: "Intermediate",
    duration: "4 hours",
  },
]

const users = [
  {
    id: "1",
    name: "John Doe",
    email: "john@example.com",
    role: "Admin",
    lastActive: "Today, 2:30 PM",
  },
  {
    id: "2",
    name: "Jane Smith",
    email: "jane@example.com",
    role: "Editor",
    lastActive: "Yesterday, 10:15 AM",
  },
  {
    id: "3",
    name: "Bob Johnson",
    email: "bob@example.com",
    role: "Student",
    lastActive: "June 10, 2025",
  },
]
