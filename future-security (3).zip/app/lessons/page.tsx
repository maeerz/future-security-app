import Link from "next/link"
import { Shield, Search, Filter } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { LessonCardWithProgress } from "@/components/lesson-card-with-progress"

export default function LessonsPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <div className="flex items-center gap-2 font-bold">
            <Shield className="h-6 w-6 text-emerald-500" />
            <Link href="/">Future Security 1.0</Link>
          </div>
          <nav className="ml-auto flex gap-4 sm:gap-6">
            <Link href="/" className="text-sm font-medium">
              Dashboard
            </Link>
            <Link href="/lessons" className="text-sm font-medium text-emerald-500 underline underline-offset-4">
              Lessons
            </Link>
            <Link href="/resources" className="text-sm font-medium">
              Resources
            </Link>
            <Link href="/certificates" className="text-sm font-medium">
              Certificates
            </Link>
            <Link href="/admin" className="text-sm font-medium">
              Admin
            </Link>
          </nav>
        </div>
      </header>
      <main className="flex-1">
        <div className="container py-8">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
              <h1 className="text-3xl font-bold">Cybersecurity Lessons</h1>
              <p className="text-muted-foreground">Browse our comprehensive collection of cybersecurity lessons</p>
            </div>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search lessons..."
                  className="w-full rounded-md pl-8 md:w-[200px] lg:w-[300px]"
                />
              </div>
              <Button variant="outline" size="icon">
                <Filter className="h-4 w-4" />
                <span className="sr-only">Filter</span>
              </Button>
            </div>
          </div>

          <Tabs defaultValue="all" className="mt-6">
            <TabsList>
              <TabsTrigger value="all">All Topics</TabsTrigger>
              <TabsTrigger value="network">Network Security</TabsTrigger>
              <TabsTrigger value="application">Application Security</TabsTrigger>
              <TabsTrigger value="cloud">Cloud Security</TabsTrigger>
              <TabsTrigger value="compliance">Compliance</TabsTrigger>
            </TabsList>
            <TabsContent value="all" className="mt-6">
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {lessons.map((lesson) => (
                  <LessonCardWithProgress key={lesson.id} lesson={lesson} />
                ))}
              </div>
            </TabsContent>
            <TabsContent value="network" className="mt-6">
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {lessons
                  .filter((lesson) => lesson.category === "Network Security")
                  .map((lesson) => (
                    <LessonCardWithProgress key={lesson.id} lesson={lesson} />
                  ))}
              </div>
            </TabsContent>
            <TabsContent value="application" className="mt-6">
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {lessons
                  .filter((lesson) => lesson.category === "Application Security")
                  .map((lesson) => (
                    <LessonCardWithProgress key={lesson.id} lesson={lesson} />
                  ))}
              </div>
            </TabsContent>
            <TabsContent value="cloud" className="mt-6">
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {lessons
                  .filter((lesson) => lesson.category === "Cloud Security")
                  .map((lesson) => (
                    <LessonCardWithProgress key={lesson.id} lesson={lesson} />
                  ))}
              </div>
            </TabsContent>
            <TabsContent value="compliance" className="mt-6">
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {lessons
                  .filter((lesson) => lesson.category === "Compliance")
                  .map((lesson) => (
                    <LessonCardWithProgress key={lesson.id} lesson={lesson} />
                  ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <footer className="border-t py-6 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-24 md:flex-row">
          <div className="flex items-center gap-2 font-bold">
            <Shield className="h-5 w-5 text-emerald-500" />
            <span>Future Security 1.0</span>
          </div>
          <p className="text-center text-sm leading-loose text-muted-foreground md:text-left">
            © 2025 Future Security. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  )
}

const lessons = [
  {
    id: "network-fundamentals",
    title: "Network Security Fundamentals",
    description: "Learn the basics of securing network infrastructure",
    category: "Network Security",
    difficulty: "Beginner",
    duration: "2 hours",
  },
  {
    id: "firewall-configuration",
    title: "Firewall Configuration Best Practices",
    description: "Configure firewalls to protect your network perimeter",
    category: "Network Security",
    difficulty: "Intermediate",
    duration: "3 hours",
  },
  {
    id: "secure-coding",
    title: "Secure Coding Practices",
    description: "Write code that's resistant to common vulnerabilities",
    category: "Application Security",
    difficulty: "Intermediate",
    duration: "4 hours",
  },
  {
    id: "cloud-security",
    title: "Cloud Security Architecture",
    description: "Design secure cloud environments for your applications",
    category: "Cloud Security",
    difficulty: "Advanced",
    duration: "5 hours",
  },
  {
    id: "penetration-testing",
    title: "Introduction to Penetration Testing",
    description: "Learn ethical hacking techniques to find vulnerabilities",
    category: "Application Security",
    difficulty: "Advanced",
    duration: "6 hours",
  },
  {
    id: "gdpr-compliance",
    title: "GDPR Compliance for Security Teams",
    description: "Understand how to implement GDPR requirements",
    category: "Compliance",
    difficulty: "Beginner",
    duration: "2 hours",
  },
]
