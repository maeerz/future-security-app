"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Shield, ArrowLeft, Clock, BookOpen, Award, CheckCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useProgress } from "@/contexts/progress-context"
import { CertificateDownload } from "@/components/certificate-download"

export default function LessonPage({ params }) {
  const { getLessonProgress, markSectionComplete, updateQuizScore, updateLessonProgress } = useProgress()
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({})
  const [quizSubmitted, setQuizSubmitted] = useState(false)

  // In a real app, you would fetch the lesson data based on the ID
  const lesson = lessons.find((l) => l.id === params.id) || lessons[0]
  const progress = getLessonProgress(lesson.id)

  // Update last accessed time when component mounts
  useEffect(() => {
    updateLessonProgress(lesson.id, {
      lastAccessed: new Date().toISOString(),
    })
  }, [lesson.id, updateLessonProgress])

  const handleSectionComplete = (sectionIndex: number) => {
    markSectionComplete(lesson.id, `section-${sectionIndex}`)
  }

  const handleQuizSubmit = () => {
    let correctAnswers = 0
    lesson.quiz.forEach((question, index) => {
      if (selectedAnswers[index] === question.correctAnswer) {
        correctAnswers++
      }
    })

    const score = Math.round((correctAnswers / lesson.quiz.length) * 100)
    updateQuizScore(lesson.id, score)
    setQuizSubmitted(true)

    // If quiz score is above 70%, mark lesson as completed
    if (score >= 70) {
      updateLessonProgress(lesson.id, {
        completed: true,
        progress: 100,
      })
    }
  }

  const handleAnswerSelect = (questionIndex: number, answerIndex: number) => {
    setSelectedAnswers((prev) => ({
      ...prev,
      [questionIndex]: answerIndex,
    }))
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <div className="flex items-center gap-2 font-bold">
            <Shield className="h-6 w-6 text-emerald-500" />
            <Link href="/">Future Security 1.0</Link>
          </div>
          <nav className="ml-auto flex gap-4 sm:gap-6">
            <Link href="/" className="text-sm font-medium">
              Dashboard
            </Link>
            <Link href="/lessons" className="text-sm font-medium text-emerald-500 underline underline-offset-4">
              Lessons
            </Link>
            <Link href="/resources" className="text-sm font-medium">
              Resources
            </Link>
            <Link href="/admin" className="text-sm font-medium">
              Admin
            </Link>
          </nav>
        </div>
      </header>
      <main className="flex-1">
        <div className="container py-8">
          <div className="mb-8">
            <Link
              href="/lessons"
              className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Lessons
            </Link>
          </div>

          <div className="grid gap-8 lg:grid-cols-[1fr_300px]">
            <div>
              <div className="mb-6">
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant={getBadgeVariant(lesson.difficulty)}>{lesson.difficulty}</Badge>
                  <Badge variant="outline">{lesson.category}</Badge>
                  <Badge variant="outline">{lesson.duration}</Badge>
                  {progress.completed && (
                    <Badge variant="default" className="bg-emerald-500">
                      <CheckCircle className="h-3 w-3 mr-1" />
                      Completed
                    </Badge>
                  )}
                </div>
                <h1 className="text-3xl font-bold">{lesson.title}</h1>
                <p className="text-muted-foreground mt-2">{lesson.description}</p>
              </div>

              <Tabs defaultValue="content">
                <TabsList className="mb-4">
                  <TabsTrigger value="content">Lesson Content</TabsTrigger>
                  <TabsTrigger value="resources">Resources</TabsTrigger>
                  <TabsTrigger value="quiz">Quiz</TabsTrigger>
                </TabsList>
                <TabsContent value="content" className="space-y-6">
                  {lesson.content.map((section, index) => (
                    <Card key={index} className="space-y-4">
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-2xl">{section.title}</CardTitle>
                          {progress.sectionsCompleted.includes(`section-${index}`) ? (
                            <CheckCircle className="h-5 w-5 text-emerald-500" />
                          ) : (
                            <Button variant="outline" size="sm" onClick={() => handleSectionComplete(index)}>
                              Mark Complete
                            </Button>
                          )}
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="mb-4">{section.content}</p>
                        {section.subSections &&
                          section.subSections.map((subSection, subIndex) => (
                            <div key={subIndex} className="ml-4 space-y-2 mt-4">
                              <h3 className="text-xl font-semibold">{subSection.title}</h3>
                              <p>{subSection.content}</p>
                            </div>
                          ))}
                      </CardContent>
                    </Card>
                  ))}
                </TabsContent>
                <TabsContent value="resources">
                  <div className="space-y-4">
                    <h2 className="text-2xl font-bold">Additional Resources</h2>
                    <ul className="space-y-2">
                      {lesson.resources.map((resource, index) => (
                        <li key={index}>
                          <Link href={resource.url} className="text-emerald-600 hover:underline">
                            {resource.title}
                          </Link>
                          <p className="text-sm text-muted-foreground">{resource.description}</p>
                        </li>
                      ))}
                    </ul>
                  </div>
                </TabsContent>
                <TabsContent value="quiz">
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <h2 className="text-2xl font-bold">Knowledge Check</h2>
                      {progress.quizScore !== undefined && (
                        <Badge variant={progress.quizScore >= 70 ? "default" : "destructive"}>
                          Score: {progress.quizScore}%
                        </Badge>
                      )}
                    </div>
                    <p>Test your understanding of the lesson content with this quiz.</p>

                    {lesson.quiz.map((question, index) => (
                      <Card key={index} className="mb-4">
                        <CardHeader>
                          <CardTitle>Question {index + 1}</CardTitle>
                          <CardDescription>{question.question}</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            {question.options.map((option, optionIndex) => (
                              <div key={optionIndex} className="flex items-center space-x-2">
                                <input
                                  type="radio"
                                  id={`q${index}-option${optionIndex}`}
                                  name={`question-${index}`}
                                  className="h-4 w-4 border-gray-300 text-emerald-600 focus:ring-emerald-500"
                                  onChange={() => handleAnswerSelect(index, optionIndex)}
                                  disabled={quizSubmitted}
                                />
                                <label
                                  htmlFor={`q${index}-option${optionIndex}`}
                                  className={`text-sm ${
                                    quizSubmitted && optionIndex === question.correctAnswer
                                      ? "text-emerald-600 font-semibold"
                                      : quizSubmitted &&
                                          selectedAnswers[index] === optionIndex &&
                                          optionIndex !== question.correctAnswer
                                        ? "text-red-600"
                                        : ""
                                  }`}
                                >
                                  {option}
                                </label>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    ))}

                    {!quizSubmitted ? (
                      <Button
                        onClick={handleQuizSubmit}
                        disabled={Object.keys(selectedAnswers).length !== lesson.quiz.length}
                      >
                        Submit Quiz
                      </Button>
                    ) : (
                      <div className="p-4 rounded-lg bg-muted">
                        <p className="font-semibold">Quiz completed! Your score: {progress.quizScore}%</p>
                        {progress.quizScore >= 70 ? (
                          <p className="text-emerald-600">Congratulations! You've completed this lesson.</p>
                        ) : (
                          <p className="text-amber-600">You may want to review the content and retake the quiz.</p>
                        )}
                      </div>
                    )}
                  </div>
                </TabsContent>
              </Tabs>
            </div>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Your Progress</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Lesson Progress</span>
                        <span>{Math.round(progress.progress)}%</span>
                      </div>
                      <Progress value={progress.progress} className="h-2" />
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <span>Estimated time: {lesson.duration}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <BookOpen className="h-4 w-4 text-muted-foreground" />
                        <span>{lesson.content.length} sections</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <Award className="h-4 w-4 text-muted-foreground" />
                        <span>Certificate upon completion</span>
                      </div>
                      {progress.timeSpent > 0 && (
                        <div className="flex items-center gap-2 text-sm">
                          <Clock className="h-4 w-4 text-muted-foreground" />
                          <span>
                            Time spent: {Math.floor(progress.timeSpent / 60)}h {progress.timeSpent % 60}m
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>

              <CertificateDownload lessonId={lesson.id} lessonTitle={lesson.title} duration={lesson.duration} />

              <Card>
                <CardHeader>
                  <CardTitle>Section Progress</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {lesson.content.map((section, index) => (
                      <div key={index} className="flex items-center gap-2 text-sm">
                        {progress.sectionsCompleted.includes(`section-${index}`) ? (
                          <CheckCircle className="h-4 w-4 text-emerald-500" />
                        ) : (
                          <div className="h-4 w-4 rounded-full border-2 border-muted-foreground" />
                        )}
                        <span
                          className={
                            progress.sectionsCompleted.includes(`section-${index}`)
                              ? "line-through text-muted-foreground"
                              : ""
                          }
                        >
                          {section.title}
                        </span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Related Lessons</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {lesson.relatedLessons.map((relatedLesson, index) => (
                      <li key={index}>
                        <Link href={`/lessons/${relatedLesson.id}`} className="text-emerald-600 hover:underline">
                          {relatedLesson.title}
                        </Link>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
      <footer className="border-t py-6 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-24 md:flex-row">
          <div className="flex items-center gap-2 font-bold">
            <Shield className="h-5 w-5 text-emerald-500" />
            <span>Future Security 1.0</span>
          </div>
          <p className="text-center text-sm leading-loose text-muted-foreground md:text-left">
            © 2025 Future Security. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  )
}

function getBadgeVariant(difficulty) {
  switch (difficulty) {
    case "Beginner":
      return "secondary"
    case "Intermediate":
      return "default"
    case "Advanced":
      return "destructive"
    default:
      return "outline"
  }
}

const lessons = [
  {
    id: "network-fundamentals",
    title: "Network Security Fundamentals",
    description: "Learn the basics of securing network infrastructure",
    category: "Network Security",
    difficulty: "Beginner",
    duration: "2 hours",
    content: [
      {
        title: "Introduction to Network Security",
        content:
          "Network security consists of the policies, processes and practices adopted to prevent, detect and monitor unauthorized access, misuse, modification, or denial of a computer network and network-accessible resources.",
        subSections: [
          {
            title: "Why Network Security Matters",
            content:
              "Network security is crucial because organizations transmit sensitive data across networks and to other devices in the course of doing businesses, and network security helps ensure safe data transmission.",
          },
          {
            title: "Common Network Threats",
            content:
              "Common network security threats include malware, ransomware, social engineering, and man-in-the-middle attacks.",
          },
        ],
      },
      {
        title: "Network Security Components",
        content:
          "A comprehensive network security implementation includes multiple defense layers. No single solution protects from all types of threats.",
        subSections: [
          {
            title: "Firewalls",
            content:
              "Firewalls monitor and filter incoming and outgoing network traffic based on an organization's previously established security policies.",
          },
          {
            title: "Intrusion Prevention Systems (IPS)",
            content: "IPS scans network traffic to actively block attacks against your network.",
          },
          {
            title: "Virtual Private Networks (VPNs)",
            content:
              "VPNs create a secure, encrypted connection over a less secure network, such as the public internet.",
          },
        ],
      },
      {
        title: "Network Security Best Practices",
        content: "Implementing these best practices can significantly improve your network security posture.",
        subSections: [
          {
            title: "Regular Updates and Patching",
            content:
              "Keep all network devices, operating systems, and applications updated with the latest security patches.",
          },
          {
            title: "Strong Authentication",
            content: "Implement multi-factor authentication for accessing network resources.",
          },
          {
            title: "Network Segmentation",
            content:
              "Divide your network into segments to limit the spread of intrusions and improve security and performance.",
          },
        ],
      },
    ],
    resources: [
      {
        title: "NIST Cybersecurity Framework",
        description: "A set of guidelines for mitigating organizational cybersecurity risks",
        url: "https://www.nist.gov/cyberframework",
      },
      {
        title: "SANS Network Security Resources",
        description: "Collection of network security resources from the SANS Institute",
        url: "https://www.sans.org/network-security",
      },
      {
        title: "Wireshark Network Protocol Analyzer",
        description: "Free and open-source packet analyzer for network troubleshooting and analysis",
        url: "https://www.wireshark.org/",
      },
    ],
    quiz: [
      {
        question: "What is the primary purpose of a firewall in network security?",
        options: [
          "To encrypt all network traffic",
          "To monitor and filter incoming and outgoing network traffic",
          "To speed up network connections",
          "To store backup copies of network data",
        ],
        correctAnswer: 1,
      },
      {
        question: "Which of the following is NOT a common network security threat?",
        options: ["Malware", "Social engineering", "Database normalization", "Man-in-the-middle attacks"],
        correctAnswer: 2,
      },
      {
        question: "What is network segmentation?",
        options: [
          "The process of dividing a computer network into subnetworks",
          "Encrypting network traffic",
          "Monitoring network performance",
          "Backing up network configurations",
        ],
        correctAnswer: 0,
      },
    ],
    relatedLessons: [
      {
        id: "firewall-configuration",
        title: "Firewall Configuration Best Practices",
      },
      {
        id: "intrusion-detection",
        title: "Intrusion Detection Systems",
      },
      {
        id: "vpn-setup",
        title: "Setting Up Secure VPNs",
      },
    ],
  },
]
