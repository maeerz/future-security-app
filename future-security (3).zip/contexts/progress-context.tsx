"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState } from "react"

interface Certificate {
  id: string
  lessonId: string
  lessonTitle: string
  earnedDate: string
  score?: number
  duration: string
}

interface LessonProgress {
  lessonId: string
  completed: boolean
  progress: number // 0-100
  timeSpent: number // in minutes
  lastAccessed: string
  sectionsCompleted: string[]
  quizScore?: number
  certificateEarned?: boolean
}

interface ProgressContextType {
  userProgress: Record<string, LessonProgress>
  certificates: Certificate[]
  updateLessonProgress: (lessonId: string, progress: Partial<LessonProgress>) => void
  getLessonProgress: (lessonId: string) => LessonProgress
  getOverallProgress: () => {
    totalLessons: number
    completedLessons: number
    averageProgress: number
    totalTimeSpent: number
  }
  markSectionComplete: (lessonId: string, sectionId: string) => void
  updateQuizScore: (lessonId: string, score: number) => void
  generateCertificate: (lessonId: string, lessonTitle: string, duration: string) => void
  getCertificate: (lessonId: string) => Certificate | undefined
}

const ProgressContext = createContext<ProgressContextType | undefined>(undefined)

export function ProgressProvider({ children }: { children: React.ReactNode }) {
  const [userProgress, setUserProgress] = useState<Record<string, LessonProgress>>({})
  const [certificates, setCertificates] = useState<Certificate[]>([])

  // Load progress from localStorage on mount
  useEffect(() => {
    const savedProgress = localStorage.getItem("futureSecurityProgress")
    const savedCertificates = localStorage.getItem("futureSecurityCertificates")

    if (savedProgress) {
      try {
        setUserProgress(JSON.parse(savedProgress))
      } catch (error) {
        console.error("Failed to load progress from localStorage:", error)
      }
    }

    if (savedCertificates) {
      try {
        setCertificates(JSON.parse(savedCertificates))
      } catch (error) {
        console.error("Failed to load certificates from localStorage:", error)
      }
    }
  }, [])

  // Save progress to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("futureSecurityProgress", JSON.stringify(userProgress))
  }, [userProgress])

  // Save certificates to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem("futureSecurityCertificates", JSON.stringify(certificates))
  }, [certificates])

  const updateLessonProgress = (lessonId: string, progress: Partial<LessonProgress>) => {
    setUserProgress((prev) => ({
      ...prev,
      [lessonId]: {
        ...prev[lessonId],
        lessonId,
        completed: false,
        progress: 0,
        timeSpent: 0,
        lastAccessed: new Date().toISOString(),
        sectionsCompleted: [],
        ...progress,
      },
    }))
  }

  const getLessonProgress = (lessonId: string): LessonProgress => {
    return (
      userProgress[lessonId] || {
        lessonId,
        completed: false,
        progress: 0,
        timeSpent: 0,
        lastAccessed: new Date().toISOString(),
        sectionsCompleted: [],
      }
    )
  }

  const getOverallProgress = () => {
    const progressValues = Object.values(userProgress)
    const totalLessons = Math.max(progressValues.length, 6) // Minimum 6 lessons for demo
    const completedLessons = progressValues.filter((p) => p.completed).length
    const averageProgress =
      progressValues.length > 0 ? progressValues.reduce((sum, p) => sum + p.progress, 0) / progressValues.length : 0
    const totalTimeSpent = progressValues.reduce((sum, p) => sum + p.timeSpent, 0)

    return {
      totalLessons,
      completedLessons,
      averageProgress,
      totalTimeSpent,
    }
  }

  const markSectionComplete = (lessonId: string, sectionId: string) => {
    const currentProgress = getLessonProgress(lessonId)
    const sectionsCompleted = [...currentProgress.sectionsCompleted]

    if (!sectionsCompleted.includes(sectionId)) {
      sectionsCompleted.push(sectionId)
    }

    // Calculate progress based on sections completed (assuming 3 sections per lesson)
    const progress = Math.min((sectionsCompleted.length / 3) * 100, 100)
    const completed = progress === 100

    updateLessonProgress(lessonId, {
      sectionsCompleted,
      progress,
      completed,
      timeSpent: currentProgress.timeSpent + 5, // Add 5 minutes per section
    })
  }

  const updateQuizScore = (lessonId: string, score: number) => {
    const currentProgress = getLessonProgress(lessonId)
    const completed = score >= 70 // Pass threshold

    updateLessonProgress(lessonId, {
      quizScore: score,
      completed,
      progress: completed ? 100 : currentProgress.progress,
    })
  }

  const generateCertificate = (lessonId: string, lessonTitle: string, duration: string) => {
    const progress = getLessonProgress(lessonId)

    if (!progress.completed) {
      return
    }

    // Check if certificate already exists
    const existingCertificate = certificates.find((cert) => cert.lessonId === lessonId)
    if (existingCertificate) {
      return
    }

    const certificate: Certificate = {
      id: `cert_${lessonId}_${Date.now()}`,
      lessonId,
      lessonTitle,
      earnedDate: new Date().toISOString(),
      score: progress.quizScore,
      duration,
    }

    setCertificates((prev) => [...prev, certificate])

    // Mark certificate as earned in progress
    updateLessonProgress(lessonId, {
      certificateEarned: true,
    })
  }

  const getCertificate = (lessonId: string): Certificate | undefined => {
    return certificates.find((cert) => cert.lessonId === lessonId)
  }

  return (
    <ProgressContext.Provider
      value={{
        userProgress,
        certificates,
        updateLessonProgress,
        getLessonProgress,
        getOverallProgress,
        markSectionComplete,
        updateQuizScore,
        generateCertificate,
        getCertificate,
      }}
    >
      {children}
    </ProgressContext.Provider>
  )
}

export function useProgress() {
  const context = useContext(ProgressContext)
  if (context === undefined) {
    throw new Error("useProgress must be used within a ProgressProvider")
  }
  return context
}
