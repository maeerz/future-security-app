"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useProgress } from "@/contexts/progress-context"
import { downloadCertificate, type CertificateData } from "@/lib/certificate-generator"
import { Download, Award, Calendar, Trophy } from "lucide-react"

interface CertificateDownloadProps {
  lessonId: string
  lessonTitle: string
  duration: string
}

export function CertificateDownload({ lessonId, lessonTitle, duration }: CertificateDownloadProps) {
  const { getLessonProgress, generateCertificate, getCertificate } = useProgress()
  const progress = getLessonProgress(lessonId)
  const certificate = getCertificate(lessonId)

  const handleGenerateCertificate = () => {
    if (!progress.completed) return

    // Generate certificate record if it doesn't exist
    if (!certificate) {
      generateCertificate(lessonId, lessonTitle, duration)
    }

    // Download the certificate
    const certificateData: CertificateData = {
      studentName: "Cybersecurity Student", // In a real app, this would come from user data
      lessonTitle,
      completionDate: new Date().toLocaleDateString("en-US", {
        year: "numeric",
        month: "long",
        day: "numeric",
      }),
      score: progress.quizScore,
      duration,
      certificateId: certificate?.id || `cert_${lessonId}_${Date.now()}`,
    }

    downloadCertificate(certificateData)
  }

  if (!progress.completed) {
    return (
      <Card className="border-dashed">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-muted-foreground">
            <Award className="h-5 w-5" />
            Certificate Not Available
          </CardTitle>
          <CardDescription>Complete this lesson and pass the quiz to earn your certificate</CardDescription>
        </CardHeader>
      </Card>
    )
  }

  return (
    <Card className="border-emerald-200 bg-emerald-50/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-emerald-700">
          <Trophy className="h-5 w-5" />
          Certificate Available
        </CardTitle>
        <CardDescription>Congratulations! You've completed this lesson and earned a certificate.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {certificate && (
          <div className="space-y-2 text-sm">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Calendar className="h-4 w-4" />
              <span>Earned: {new Date(certificate.earnedDate).toLocaleDateString()}</span>
            </div>
            {certificate.score && (
              <div className="flex items-center gap-2 text-muted-foreground">
                <Trophy className="h-4 w-4" />
                <span>Final Score: {certificate.score}%</span>
              </div>
            )}
          </div>
        )}
        <Button onClick={handleGenerateCertificate} className="w-full">
          <Download className="mr-2 h-4 w-4" />
          Download Certificate
        </Button>
      </CardContent>
    </Card>
  )
}
