"use client"

import Link from "next/link"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { useProgress } from "@/contexts/progress-context"
import { CheckCircle } from "lucide-react"

interface Lesson {
  id: string
  title: string
  description: string
  category: string
  difficulty: string
  duration: string
}

interface LessonCardWithProgressProps {
  lesson: Lesson
}

export function LessonCardWithProgress({ lesson }: LessonCardWithProgressProps) {
  const { getLessonProgress } = useProgress()
  const progress = getLessonProgress(lesson.id)

  return (
    <Card className="flex flex-col">
      <CardHeader>
        <div className="flex items-center justify-between">
          <Badge variant={getBadgeVariant(lesson.difficulty)}>{lesson.difficulty}</Badge>
          <Badge variant="outline">{lesson.duration}</Badge>
        </div>
        <div className="flex items-center gap-2 mt-2">
          <CardTitle className="flex-1">{lesson.title}</CardTitle>
          {progress.completed && <CheckCircle className="h-5 w-5 text-emerald-500" />}
        </div>
        <CardDescription>{lesson.description}</CardDescription>
      </CardHeader>
      <CardContent className="flex-1">
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span>Category: {lesson.category}</span>
          </div>
          {progress.progress > 0 && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Progress</span>
                <span>{Math.round(progress.progress)}%</span>
              </div>
              <Progress value={progress.progress} className="h-2" />
              {progress.timeSpent > 0 && (
                <p className="text-xs text-muted-foreground">
                  Time spent: {Math.floor(progress.timeSpent / 60)}h {progress.timeSpent % 60}m
                </p>
              )}
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter>
        <Link href={`/lessons/${lesson.id}`} className="w-full">
          <Button className="w-full">
            {progress.completed ? "Review Lesson" : progress.progress > 0 ? "Continue" : "Start Lesson"}
          </Button>
        </Link>
      </CardFooter>
    </Card>
  )
}

function getBadgeVariant(difficulty: string) {
  switch (difficulty) {
    case "Beginner":
      return "secondary"
    case "Intermediate":
      return "default"
    case "Advanced":
      return "destructive"
    default:
      return "outline"
  }
}
