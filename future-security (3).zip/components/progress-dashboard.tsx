"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { useProgress } from "@/contexts/progress-context"
import { Clock, BookOpen, Award, TrendingUp } from "lucide-react"

export function ProgressDashboard() {
  const { getOverallProgress, userProgress } = useProgress()
  const overallProgress = getOverallProgress()

  const recentLessons = Object.values(userProgress)
    .sort((a, b) => new Date(b.lastAccessed).getTime() - new Date(a.lastAccessed).getTime())
    .slice(0, 3)

  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Lessons Completed</CardTitle>
          <BookOpen className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{overallProgress.completedLessons}</div>
          <p className="text-xs text-muted-foreground">of {overallProgress.totalLessons} total lessons</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Overall Progress</CardTitle>
          <TrendingUp className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{Math.round(overallProgress.averageProgress)}%</div>
          <Progress value={overallProgress.averageProgress} className="mt-2" />
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Time Spent Learning</CardTitle>
          <Clock className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{Math.round(overallProgress.totalTimeSpent / 60)}h</div>
          <p className="text-xs text-muted-foreground">{overallProgress.totalTimeSpent % 60}m additional</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Certificates Earned</CardTitle>
          <Award className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{overallProgress.completedLessons}</div>
          <p className="text-xs text-muted-foreground">Available for download</p>
        </CardContent>
      </Card>

      {recentLessons.length > 0 && (
        <Card className="md:col-span-2 lg:col-span-4">
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Your recently accessed lessons</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentLessons.map((lesson) => (
                <div key={lesson.lessonId} className="flex items-center justify-between">
                  <div className="space-y-1">
                    <p className="text-sm font-medium leading-none">{getLessonTitle(lesson.lessonId)}</p>
                    <p className="text-sm text-muted-foreground">
                      Last accessed: {new Date(lesson.lastAccessed).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant={lesson.completed ? "default" : "secondary"}>
                      {lesson.completed ? "Completed" : `${Math.round(lesson.progress)}%`}
                    </Badge>
                    <Progress value={lesson.progress} className="w-20" />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

function getLessonTitle(lessonId: string): string {
  const lessonTitles: Record<string, string> = {
    "network-fundamentals": "Network Security Fundamentals",
    "firewall-configuration": "Firewall Configuration Best Practices",
    "secure-coding": "Secure Coding Practices",
    "cloud-security": "Cloud Security Architecture",
    "penetration-testing": "Introduction to Penetration Testing",
    "gdpr-compliance": "GDPR Compliance for Security Teams",
  }
  return lessonTitles[lessonId] || "Unknown Lesson"
}
