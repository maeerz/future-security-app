import jsPDF from "jspdf"

export interface CertificateData {
  studentName: string
  lessonTitle: string
  completionDate: string
  score?: number
  duration: string
  certificateId: string
}

export function generateCertificate(data: CertificateData): jsPDF {
  const pdf = new jsPDF({
    orientation: "landscape",
    unit: "mm",
    format: "a4",
  })

  // Set background color
  pdf.setFillColor(248, 250, 252) // Light gray background
  pdf.rect(0, 0, 297, 210, "F")

  // Add border
  pdf.setDrawColor(34, 197, 94) // Emerald color
  pdf.setLineWidth(2)
  pdf.rect(10, 10, 277, 190)

  // Add inner border
  pdf.setDrawColor(34, 197, 94)
  pdf.setLineWidth(1)
  pdf.rect(15, 15, 267, 180)

  // Add header
  pdf.setFontSize(28)
  pdf.setTextColor(34, 197, 94)
  pdf.setFont("helvetica", "bold")
  pdf.text("CERTIFICATE OF COMPLETION", 148.5, 40, { align: "center" })

  // Add subtitle
  pdf.setFontSize(16)
  pdf.setTextColor(100, 116, 139)
  pdf.setFont("helvetica", "normal")
  pdf.text("Future Security 1.0 - Cybersecurity Education Platform", 148.5, 50, { align: "center" })

  // Add main text
  pdf.setFontSize(14)
  pdf.setTextColor(51, 65, 85)
  pdf.text("This is to certify that", 148.5, 70, { align: "center" })

  // Add student name
  pdf.setFontSize(24)
  pdf.setTextColor(34, 197, 94)
  pdf.setFont("helvetica", "bold")
  pdf.text(data.studentName, 148.5, 85, { align: "center" })

  // Add completion text
  pdf.setFontSize(14)
  pdf.setTextColor(51, 65, 85)
  pdf.setFont("helvetica", "normal")
  pdf.text("has successfully completed the course", 148.5, 100, { align: "center" })

  // Add lesson title
  pdf.setFontSize(20)
  pdf.setTextColor(34, 197, 94)
  pdf.setFont("helvetica", "bold")
  pdf.text(data.lessonTitle, 148.5, 115, { align: "center" })

  // Add completion details
  pdf.setFontSize(12)
  pdf.setTextColor(100, 116, 139)
  pdf.setFont("helvetica", "normal")

  let detailsY = 135
  pdf.text(`Completion Date: ${data.completionDate}`, 148.5, detailsY, { align: "center" })

  if (data.score) {
    detailsY += 8
    pdf.text(`Final Score: ${data.score}%`, 148.5, detailsY, { align: "center" })
  }

  detailsY += 8
  pdf.text(`Course Duration: ${data.duration}`, 148.5, detailsY, { align: "center" })

  // Add certificate ID
  pdf.setFontSize(10)
  pdf.setTextColor(148, 163, 184)
  pdf.text(`Certificate ID: ${data.certificateId}`, 148.5, 175, { align: "center" })

  // Add signature line
  pdf.setDrawColor(100, 116, 139)
  pdf.setLineWidth(0.5)
  pdf.line(200, 160, 270, 160)
  pdf.setFontSize(10)
  pdf.setTextColor(100, 116, 139)
  pdf.text("Future Security Team", 235, 167, { align: "center" })

  // Add logo placeholder (shield icon representation)
  pdf.setDrawColor(34, 197, 94)
  pdf.setFillColor(34, 197, 94)
  pdf.setLineWidth(2)

  // Draw shield shape
  const shieldX = 40
  const shieldY = 45
  const shieldWidth = 20
  const shieldHeight = 25

  pdf.rect(shieldX, shieldY, shieldWidth, shieldHeight, "D")
  pdf.triangle(
    shieldX,
    shieldY + shieldHeight,
    shieldX + shieldWidth / 2,
    shieldY + shieldHeight + 8,
    shieldX + shieldWidth,
    shieldY + shieldHeight,
    "D",
  )

  return pdf
}

export function downloadCertificate(data: CertificateData): void {
  const pdf = generateCertificate(data)
  const fileName = `${data.lessonTitle.replace(/[^a-z0-9]/gi, "_").toLowerCase()}_certificate.pdf`
  pdf.save(fileName)
}
